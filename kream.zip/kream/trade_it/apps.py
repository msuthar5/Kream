from django.apps import AppConfig


class TradeItConfig(AppConfig):
    name = 'trade_it'
